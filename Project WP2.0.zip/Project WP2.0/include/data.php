<?php
header('Content-Type: application/json');

$totalMahasiswa = count($dummyData);
$kehadiranHariIni = rand(80, 100); // Simulate today's attendance
$rataKehadiran = $totalMahasiswa > 0 ? round(array_sum(array_column($dummyData, 'persentase')) / $totalMahasiswa) : 0;

$response = [
    'success' => true,
    'tahunAjaran' => $tahunAjaran,
    'semester' => $semester,
    'jurusan' => $jurusan,
    'totalMahasiswa' => $totalMahasiswa,
    'kehadiranHariIni' => $kehadiranHariIni,
    'rataKehadiran' => $rataKehadiran,
    'data' => $dummyData
];

echo json_encode($response);
// Data dummy mahasiswa
$mahasiswa = [
    ['nim' => '2023001', 'nama' => 'Andi Wijaya', 'jurusan' => 'Teknik Informatika', 'semester' => 3, 'email' => 'andi@email.com'],
    ['nim' => '2023002', 'nama' => 'Budi Santoso', 'jurusan' => 'Sistem Informasi', 'semester' => 2, 'email' => 'budi@email.com'],
    ['nim' => '2023003', 'nama' => 'Citra Dewi', 'jurusan' => 'Teknik Komputer', 'semester' => 4, 'email' => 'citra@email.com'],
    ['nim' => '2023004', 'nama' => 'Dian Pratama', 'jurusan' => 'Teknik Informatika', 'semester' => 1, 'email' => 'dian@email.com'],
    ['nim' => '2023005', 'nama' => 'Eka Putri', 'jurusan' => 'Sistem Informasi', 'semester' => 5, 'email' => 'eka@email.com'],
];

foreach ($mahasiswa as $index => $mhs) {
    echo "<tr>
            <td>" . ($index + 1) . "</td>
            <td>{$mhs['nim']}</td>
            <td>{$mhs['nama']}</td>
            <td>{$mhs['jurusan']}</td>
            <td>{$mhs['semester']}</td>
            <td>{$mhs['email']}</td>
            <td>
                <button class='btn-action btn-edit'><i class='fas fa-edit'></i> Edit</button>
                <button class='btn-action btn-delete'><i class='fas fa-trash'></i> Hapus</button>
            </td>
          </tr>";
}

header("Content-Type: application/json");

$data = [
    ["nim" => "123456", "nama" => "Andi Saputra", "jurusan" => "Teknik Informatika", "semester" => 3, "email" => "andi@example.com"],
    ["nim" => "789012", "nama" => "Budi Santoso", "jurusan" => "Sistem Informasi", "semester" => 5, "email" => "budi@example.com"],
    ["nim" => "345678", "nama" => "Cindy Wijaya", "jurusan" => "Teknik Komputer", "semester" => 2, "email" => "cindy@example.com"]
];

echo json_encode($data);
