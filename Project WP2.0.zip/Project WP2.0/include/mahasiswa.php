<?php
session_start();

$dataFile = __DIR__ . '/mahasiswa_data.json';

// Inisialisasi data jika file belum ada
if (!file_exists($dataFile)) {
    $init = [
        ['nim' => '123456', 'nama' => 'Andi Saputra', 'jurusan' => 'Teknik Informatika', 'semester' => 3, 'email' => 'andi@email.com'],
        ['nim' => '789012', 'nama' => 'Budi Santoso', 'jurusan' => 'Sistem Informasi', 'semester' => 5, 'email' => 'budi@email.com'],
        ['nim' => '345678', 'nama' => 'Cindy Wijaya', 'jurusan' => 'Teknik Komputer', 'semester' => 2, 'email' => 'cindy@email.com'],
    ];
    file_put_contents($dataFile, json_encode($init, JSON_PRETTY_PRINT));
}

// Cek login
if (!isset($_SESSION['isLoggedIn'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'msg' => 'Belum login']);
    exit;
}

header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $mahasiswa = json_decode(file_get_contents($dataFile), true);
    echo json_encode($mahasiswa);
    exit;
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    $mahasiswa = json_decode(file_get_contents($dataFile), true);

    if ($action === 'add') {
        // Validasi sederhana
        $data = $input['data'];
        if (
            empty($data['nim']) || empty($data['nama']) || empty($data['jurusan']) ||
            empty($data['semester']) || empty($data['email'])
        ) {
            echo json_encode(['success' => false, 'msg' => 'Data tidak lengkap']);
            exit;
        }
        // Cek NIM unik
        foreach ($mahasiswa as $m) {
            if ($m['nim'] === $data['nim']) {
                echo json_encode(['success' => false, 'msg' => 'NIM sudah ada']);
                exit;
            }
        }
        $mahasiswa[] = $data;
        file_put_contents($dataFile, json_encode($mahasiswa, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'edit') {
        $data = $input['data'];
        $found = false;
        foreach ($mahasiswa as $i => $m) {
            if ($m['nim'] === $data['nim']) {
                $mahasiswa[$i] = $data;
                $found = true;
                break;
            }
        }
        if (!$found) {
            echo json_encode(['success' => false, 'msg' => 'Data tidak ditemukan']);
            exit;
        }
        file_put_contents($dataFile, json_encode($mahasiswa, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'delete') {
        $nim = $input['nim'];
        $found = false;
        $mahasiswa = array_values(array_filter($mahasiswa, function ($m) use ($nim, &$found) {
            if ($m['nim'] === $nim) {
                $found = true;
                return false;
            }
            return true;
        }));
        if (!$found) {
            echo json_encode(['success' => false, 'msg' => 'Data tidak ditemukan']);
            exit;
        }
        file_put_contents($dataFile, json_encode($mahasiswa, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        exit;
    }
    echo json_encode(['success' => false, 'msg' => 'Invalid action']);
    exit;
}

// Semua proses CRUD hanya untuk nim, nama, jurusan, semester, email
// Tidak ada proses untuk username/password
