<?php
session_start();

$dataFile = __DIR__ . '/matakuliah_data.json';

// Inisialisasi data jika file belum ada
if (!file_exists($dataFile)) {
    $init = [
        ['kode' => 'IF101', 'nama' => 'Algoritma dan Pemrograman', 'sks' => 3, 'jurusan' => 'Teknik Informatika'],
        ['kode' => 'SI201', 'nama' => 'Sistem Informasi Manajemen', 'sks' => 2, 'jurusan' => 'Sistem Informasi'],
        ['kode' => 'TK301', 'nama' => 'Jaringan Komputer', 'sks' => 3, 'jurusan' => 'Teknik Komputer'],
    ];
    file_put_contents($dataFile, json_encode($init, JSON_PRETTY_PRINT));
}


header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $matkul = json_decode(file_get_contents($dataFile), true);
    echo json_encode($matkul);
    exit;
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    $matkul = json_decode(file_get_contents($dataFile), true);

    if ($action === 'add') {
        $data = $input['data'];
        if (
            empty($data['kode']) || empty($data['nama']) || empty($data['sks']) ||
            empty($data['jurusan'])
        ) {
            echo json_encode(['success' => false, 'msg' => 'Data tidak lengkap']);
            exit;
        }
        // Cek kode unik
        foreach ($matkul as $m) {
            if ($m['kode'] === $data['kode']) {
                echo json_encode(['success' => false, 'msg' => 'Kode sudah ada']);
                exit;
            }
        }
        $matkul[] = $data;
        file_put_contents($dataFile, json_encode($matkul, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'edit') {
        $data = $input['data'];
        $found = false;
        foreach ($matkul as $i => $m) {
            if ($m['kode'] === $data['kode']) {
                $matkul[$i] = $data;
                $found = true;
                break;
            }
        }
        if (!$found) {
            echo json_encode(['success' => false, 'msg' => 'Data tidak ditemukan']);
            exit;
        }
        file_put_contents($dataFile, json_encode($matkul, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'delete') {
        $kode = $input['kode'];
        $found = false;
        $matkul = array_values(array_filter($matkul, function ($m) use ($kode, &$found) {
            if ($m['kode'] === $kode) {
                $found = true;
                return false;
            }
            return true;
        }));
        if (!$found) {
            echo json_encode(['success' => false, 'msg' => 'Data tidak ditemukan']);
            exit;
        }
        file_put_contents($dataFile, json_encode($matkul, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true]);
        exit;
    }
    echo json_encode(['success' => false, 'msg' => 'Invalid action']);
    exit;
}
