<?php
header('Content-Type: application/json');

// Data dummy presensi mahasiswa
$data = [
    [
        "nim" => "19241928",
        "nama" => "Hizkia Kevin Josua",
        "jurusan" => "Sistem Informasi",
        "semester" => 2,
        "email" => "Kevin123@email.com",
        "kehadiran" => "hadir", // Status kehadiran
        "persentase" => rand(70, 100) // Random percentage between 70-100
    ],
    [
        "nim" => "789012",
        "nama" => "Michael Phoenix",
        "jurusan" => "Sistem Informasi",
        "semester" => 5,
        "email" => "mchael@email.com",
        "kehadiran" => "izin", // Status kehadiran
        "persentase" => rand(70, 100) // Random percentage between 70-100
    ],
    [
        "nim" => "19241936",
        "nama" => "Muhammad Maftuh Farhan",
        "jurusan" => "Sistem Informasi",
        "semester" => 2,
        "email" => "maftuh123@gmail.com",
        "kehadiran" => "hadir", // Status kehadiran
        "persentase" => rand(70, 100) // Random percentage between 70-100
    ],
    [
        "nim" => "19241893",
        "nama" => "Aldhoni Putra Liyanto",
        "jurusan" => "Sistem Informasi",
        "semester" => 2,
        "email" => "aldho123@gmail.com",
        "kehadiran" => "alfa", // Status kehadiran
        "persentase" => rand(70, 100) // Random percentage between 70-100
    ]
];

// Hitung statistik
$totalMahasiswa = count($data);
$hadirHariIni = array_reduce($data, function ($carry, $item) {
    return $carry + ($item['kehadiran'] === "hadir" ? 1 : 0);
}, 0);
$rataRataKehadiran = ($totalMahasiswa > 0) ? ($hadirHariIni / $totalMahasiswa) * 100 : 0;

// Response JSON
$response = [
    "statistik" => [
        "totalMahasiswa" => $totalMahasiswa,
        "hadirHariIni" => $hadirHariIni,
        "rataRataKehadiran" => $rataRataKehadiran
    ],
    "dataPresensi" => $data
];

echo json_encode($response);
