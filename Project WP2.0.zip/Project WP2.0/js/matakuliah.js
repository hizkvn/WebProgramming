document.addEventListener("DOMContentLoaded", function () {
  const tableBody = document.querySelector("#matkulTable tbody");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");
  const pageInfo = document.getElementById("pageInfo");
  const addBtn = document.getElementById("addMatkulBtn");
  const modal = document.getElementById("matkulModal");
  const form = document.getElementById("matkulForm");
  const closeModalBtn = document.getElementById("closeModalBtn");
  const modalTitle = document.getElementById("modalTitle");
  const formMode = document.getElementById("formMode");
  const matkulIndex = document.getElementById("matkulIndex");
  const searchInput = document.getElementById("searchMatkul");

  let currentPage = 1;
  const rowsPerPage = 5;
  let allData = [];
  let filteredData = [];

  function loadData() {
    fetch("include/matakuliah.php")
      .then((response) => response.json())
      .then((data) => {
        allData = data;
        filteredData = allData;
        renderTable();
      })
      .catch((error) => console.error("Error fetching data:", error));
  }

  function renderTable() {
    tableBody.innerHTML = "";
    const start = (currentPage - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const paginatedData = filteredData.slice(start, end);

    paginatedData.forEach((row, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${start + index + 1}</td>
        <td>${row.kode}</td>
        <td>${row.nama}</td>
        <td>${row.sks}</td>
        <td>${row.jurusan}</td>
        <td>
          <button class="btn-action btn-edit" data-index="${
            start + index
          }"><i class="fas fa-edit"></i> Edit</button>
          <button class="btn-action btn-delete" data-index="${
            start + index
          }"><i class="fas fa-trash"></i> Hapus</button>
        </td>
      `;
      tableBody.appendChild(tr);
    });

    pageInfo.textContent = `${currentPage} dari ${Math.max(
      1,
      Math.ceil(filteredData.length / rowsPerPage)
    )}`;
    updateButtons();
    addRowEventListeners();
  }

  function updateButtons() {
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled =
      currentPage === Math.ceil(filteredData.length / rowsPerPage) ||
      filteredData.length === 0;
  }

  prevBtn.addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      renderTable();
    }
  });

  nextBtn.addEventListener("click", () => {
    if (currentPage < Math.ceil(filteredData.length / rowsPerPage)) {
      currentPage++;
      renderTable();
    }
  });

  function addRowEventListeners() {
    document.querySelectorAll(".btn-edit").forEach((btn) => {
      btn.onclick = function () {
        const idx = parseInt(this.getAttribute("data-index"));
        showModal("edit", idx);
      };
    });
    document.querySelectorAll(".btn-delete").forEach((btn) => {
      btn.onclick = function () {
        const idx = parseInt(this.getAttribute("data-index"));
        if (confirm("Yakin ingin menghapus data ini?")) {
          deleteMatkul(idx);
        }
      };
    });
  }

  function showModal(mode, idx = null) {
    modal.style.display = "flex";
    formMode.value = mode;
    if (mode === "edit" && idx !== null) {
      modalTitle.textContent = "Edit Mata Kuliah";
      matkulIndex.value = idx;
      const mk = filteredData[idx];
      form.kode.value = mk.kode;
      form.nama.value = mk.nama;
      form.sks.value = mk.sks;
      form.jurusan.value = mk.jurusan;
      form.kode.disabled = true;
    } else {
      modalTitle.textContent = "Tambah Mata Kuliah";
      matkulIndex.value = "";
      form.reset();
      form.kode.disabled = false;
    }
  }

  closeModalBtn.onclick = () => {
    modal.style.display = "none";
  };

  modal.onclick = function (e) {
    if (e.target === modal) modal.style.display = "none";
  };

  addBtn.onclick = () => showModal("add");

  form.onsubmit = function (e) {
    e.preventDefault();
    const data = {
      kode: form.kode.value,
      nama: form.nama.value,
      sks: form.sks.value,
      jurusan: form.jurusan.value,
    };
    if (parseInt(data.sks) < 1) {
      alert("SKS harus lebih dari 0");
      return;
    }
    if (formMode.value === "add") {
      fetch("include/matakuliah.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "add", data }),
      })
        .then((res) => res.json())
        .then((res) => {
          if (!res.success) {
            alert(res.msg || "Gagal menambah data");
            return;
          }
          modal.style.display = "none";
          loadData();
        });
    } else if (formMode.value === "edit") {
      fetch("include/matakuliah.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "edit", data }),
      })
        .then((res) => res.json())
        .then((res) => {
          if (!res.success) {
            alert(res.msg || "Gagal mengedit data");
            return;
          }
          modal.style.display = "none";
          loadData();
        });
    }
  };

  function deleteMatkul(idx) {
    const mk = filteredData[idx];
    fetch("include/matakuliah.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", kode: mk.kode }),
    })
      .then((res) => res.json())
      .then((res) => {
        if (!res.success) {
          alert(res.msg || "Gagal menghapus data");
          return;
        }
        loadData();
      });
  }

  searchInput.addEventListener("input", function () {
    const val = this.value.toLowerCase();
    filteredData = allData.filter(
      (m) =>
        m.kode.toLowerCase().includes(val) ||
        m.nama.toLowerCase().includes(val) ||
        m.jurusan.toLowerCase().includes(val)
    );
    currentPage = 1;
    renderTable();
  });
  loadData();
});
